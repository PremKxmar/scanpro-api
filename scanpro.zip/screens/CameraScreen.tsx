import React, { useState, useEffect } from 'react';

interface CameraScreenProps {
  onCapture: () => void;
  onCancel: () => void;
}

export const CameraScreen: React.FC<CameraScreenProps> = ({ onCapture, onCancel }) => {
  const [detecting, setDetecting] = useState(true);

  return (
    <div className="bg-background-dark text-white font-display overflow-hidden h-screen w-full relative">
      {/* Fake Camera Feed */}
      <div className="absolute inset-0 z-0">
        <img 
          className="w-full h-full object-cover opacity-80" 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuAl5vW8NIHDkngyLc8jrIrjqmQEJQ0pv4BbDrIsmNzzjm3IL4fDTiXNgIcjaH_z4lWVm8DlEzlrDdO0OuNAn0zlzXQXSHYMZ-wwifnelx4vNmlGv1m3f1zn-Kr8B9-H4iovoFvwmcnxFjpWk7x6xEJP6_Z7JLMFGs2IYbXEvCh4SzpEhE3C-FibaRZaiVEojR_sY8gipAOkGqxZ5LA-aN6f7qcoHOwfgUuLAlrE157MDeC0YrJpyatoCaeA3keKPmja3EkSsoQYPpz4" 
          alt="camera feed"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/70"></div>
      </div>

      <div className="relative z-10 flex flex-col h-full justify-between">
        {/* Top Status */}
        <div className="pt-12 px-6 pb-4 flex items-start justify-between">
            <button onClick={onCancel} className="group flex items-center justify-center size-10 rounded-full bg-black/30 backdrop-blur-md border border-white/10 active:bg-white/20 transition-all">
                <span className="material-symbols-outlined text-white" style={{fontSize: 24}}>close</span>
            </button>
            
            <div className="flex flex-col gap-1 items-center bg-black/30 backdrop-blur-md rounded-2xl p-3 border border-white/5">
                <div className="relative size-10 flex items-center justify-center">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                        <path className="text-white/20" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeWidth="3"></path>
                        <path className="text-accent-cyan drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="currentColor" strokeDasharray="75, 100" strokeLinecap="round" strokeWidth="3"></path>
                    </svg>
                    <span className="material-symbols-outlined text-white text-[18px] absolute">document_scanner</span>
                </div>
                <span className="text-[10px] font-medium text-gray-300 uppercase tracking-wider">Detecting</span>
            </div>

            <button className="group flex items-center justify-center size-12 rounded-full bg-black/30 backdrop-blur-md border border-white/10 active:bg-white/20 transition-all">
                <span className="material-symbols-outlined text-white group-hover:text-accent-cyan transition-colors" style={{fontSize: 24}}>flash_on</span>
            </button>
        </div>

        {/* Center Scanner */}
        <div className="flex-1 flex flex-col items-center justify-center relative">
             <div className="relative w-[80%] aspect-[3/4] max-w-sm">
                <div className="absolute left-0 right-0 h-1 bg-accent-cyan/50 shadow-[0_0_15px_rgba(34,211,238,0.6)] animate-[scan_2s_linear_infinite] z-20" style={{
                    animation: 'scan 2s linear infinite'
                }}></div>
                <style>{`
                    @keyframes scan {
                        0% { top: 10%; opacity: 0; }
                        10% { opacity: 1; }
                        90% { opacity: 1; }
                        100% { top: 90%; opacity: 0; }
                    }
                `}</style>
                
                <div className="absolute top-0 left-0 w-10 h-10 border-t-4 border-l-4 border-accent-cyan rounded-tl-xl drop-shadow-[0_0_4px_rgba(34,211,238,0.8)]"></div>
                <div className="absolute top-0 right-0 w-10 h-10 border-t-4 border-r-4 border-accent-cyan rounded-tr-xl drop-shadow-[0_0_4px_rgba(34,211,238,0.8)]"></div>
                <div className="absolute bottom-0 right-0 w-10 h-10 border-b-4 border-r-4 border-accent-cyan rounded-br-xl drop-shadow-[0_0_4px_rgba(34,211,238,0.8)]"></div>
                <div className="absolute bottom-0 left-0 w-10 h-10 border-b-4 border-l-4 border-accent-cyan rounded-bl-xl drop-shadow-[0_0_4px_rgba(34,211,238,0.8)]"></div>
                
                <div className="absolute inset-0 border border-white/10 rounded-lg"></div>
            </div>

            <div className="mt-8 animate-float">
                <div className="flex h-10 items-center justify-center gap-x-2 rounded-full bg-black/40 backdrop-blur-lg border border-white/10 pl-5 pr-5 shadow-lg">
                    <span className="material-symbols-outlined text-accent-cyan text-[18px]">center_focus_strong</span>
                    <p className="text-white text-sm font-medium leading-normal">Position document within frame</p>
                </div>
            </div>
        </div>

        {/* Bottom Bar */}
        <div className="w-full glass-panel rounded-t-[2.5rem] pb-8 pt-6 px-8 transition-transform duration-500 ease-out translate-y-0">
            <div className="flex items-center justify-between max-w-md mx-auto relative">
                <button className="flex flex-col items-center gap-1 group relative">
                    <div className="size-12 rounded-2xl bg-white/10 overflow-hidden border border-white/20 flex items-center justify-center group-active:scale-95 transition-transform">
                        <img className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCnejH8-xJSdoELixLDkA3J-3-SsDaaaxQdp3jk7-wEYcTGJMsxLPiZHjsP3ZcLfRdCDZLL73nvD9LY17yTZFWaWLQ0DfzrGpOI-2NSGKGbeQhlfqgh4P6Sgm86XnGj_Qw4hehzpHKUYcJBwZzdqM1DGf_f7h_tJ38fa75KRzo9YAZnTFQDNzvCV3Y-hvSd0a7I1XJRsRmPcWMyzJNWHYNEO-dOPAp63M2KIO65HMxG5j7-TChrHU1WwGUbQOwGz4xL5a6t0Hv6NmBg" alt="gallery" />
                    </div>
                    <span className="text-[10px] font-medium text-white/60">Gallery</span>
                </button>

                <div className="relative group cursor-pointer -mt-6">
                    <div className="absolute inset-0 rounded-full bg-primary/30 blur-xl group-hover:bg-accent-cyan/40 transition-colors duration-500"></div>
                    <div className="size-20 rounded-full border-[3px] border-white/20 flex items-center justify-center bg-black/20 backdrop-blur-sm relative z-10">
                        <button onClick={onCapture} className="size-16 rounded-full bg-gradient-to-br from-[#6467f2] to-[#22d3ee] shadow-[0_0_20px_rgba(100,103,242,0.6)] group-active:scale-90 transition-all duration-200 flex items-center justify-center relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-1/2 bg-white/10 rounded-t-full"></div>
                            <span className="material-symbols-outlined text-white drop-shadow-md text-3xl">camera</span>
                        </button>
                    </div>
                </div>

                <button className="flex flex-col items-center gap-1 group">
                    <div className="size-12 rounded-full bg-transparent hover:bg-white/10 border border-transparent hover:border-white/10 flex items-center justify-center transition-all group-active:scale-95">
                        <span className="material-symbols-outlined text-white text-[28px]">settings</span>
                    </div>
                    <span className="text-[10px] font-medium text-white/60">Settings</span>
                </button>
            </div>
            <div className="text-center mt-4">
                <p className="text-white/40 text-xs font-medium uppercase tracking-widest">Document Mode</p>
            </div>
        </div>
      </div>
    </div>
  );
};
