import React from 'react';
import { mockDocs } from '../store';
import { DocumentItem } from '../types';

interface LibraryScreenProps {
  onScan: () => void;
  onViewDoc: (id: string) => void;
}

export const LibraryScreen: React.FC<LibraryScreenProps> = ({ onScan, onViewDoc }) => {
  return (
    <div className="relative mx-auto flex h-full min-h-screen w-full max-w-md flex-col bg-background-light dark:bg-background-dark shadow-2xl overflow-hidden">
      {/* Background Gradients */}
      <div className="fixed top-[-10%] left-[-10%] h-[500px] w-[500px] rounded-full bg-primary/20 blur-[100px] pointer-events-none"></div>
      <div className="fixed bottom-[-10%] right-[-10%] h-[400px] w-[400px] rounded-full bg-blue-600/10 blur-[100px] pointer-events-none"></div>

      {/* Top Bar */}
      <div className="sticky top-0 z-40 flex flex-col gap-4 pb-2 pt-12 px-5 glass-panel border-b-0 rounded-b-[2rem]">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Library</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{mockDocs.length} Documents</p>
          </div>
          <div className="flex gap-3">
            <button className="flex size-10 items-center justify-center rounded-full bg-black/5 dark:bg-white/5 text-slate-700 dark:text-white hover:bg-black/10 dark:hover:bg-white/10 transition active:scale-95 border border-black/5 dark:border-white/5">
              <span className="material-symbols-outlined text-[20px]">cloud_upload</span>
            </button>
            <button className="flex size-10 items-center justify-center rounded-full overflow-hidden border border-black/10 dark:border-white/10">
              <img alt="User Profile" className="h-full w-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAYIYrOcFX_UQsaWUdbEKzjP-lS4kWp_uubGdMKHMMTtBj8jz56l07OlykT1_bPT7js5WfQyO4OQ4Xm5lAL4oLCKJg9LoPQ18EYi39JYT3nDPSiL8Hwm53-OM4GFitY27pRAqdgeLFILkY0nPu76gvZhk4n0_jm1qUCOOGnli_Uf2t-p_ZToNF6rXs2n7YLF0afzkPMLh5fxva-kzjC1IsA8Mzp9SZhXMAnoj25mEiPSnD701BUFA8OIiSMdxqmJ2du4tsb59KjOd_V" />
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative w-full group">
          <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
            <span className="material-symbols-outlined text-gray-400 group-focus-within:text-primary transition-colors">search</span>
          </div>
          <input 
            className="block w-full rounded-2xl border-none bg-white dark:bg-black/20 py-3.5 pl-11 pr-4 text-sm text-slate-900 dark:text-white placeholder-gray-400 focus:ring-2 focus:ring-primary/50 dark:focus:bg-black/30 transition-all shadow-sm dark:shadow-inner" 
            placeholder="Search documents, dates, tags..." 
            type="text" 
          />
          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
            <button className="p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10 text-gray-400 transition">
              <span className="material-symbols-outlined text-[20px]">tune</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto px-5 pt-4 pb-32 no-scrollbar relative z-10">
        <div className="flex gap-3 mb-6 overflow-x-auto no-scrollbar pb-2">
          <button className="whitespace-nowrap px-5 py-2 rounded-full bg-primary text-white text-sm font-semibold shadow-glow">All Scans</button>
          <button className="whitespace-nowrap px-5 py-2 rounded-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 text-slate-600 dark:text-gray-300 text-sm font-medium hover:bg-slate-50 dark:hover:bg-white/10 transition">PDFs</button>
          <button className="whitespace-nowrap px-5 py-2 rounded-full bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 text-slate-600 dark:text-gray-300 text-sm font-medium hover:bg-slate-50 dark:hover:bg-white/10 transition">Images</button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {mockDocs.map((doc) => (
            <div 
              key={doc.id}
              onClick={() => onViewDoc(doc.id)}
              className="group relative flex flex-col gap-3 p-3 rounded-[2rem] glass-card dark:hover:bg-white/10 hover:bg-white transition-all duration-300 active:scale-[0.98] cursor-pointer"
            >
              <div className="relative aspect-[3/4] w-full overflow-hidden rounded-[1.5rem] bg-gray-200 dark:bg-gray-800 shadow-lg group-hover:shadow-primary/20 transition-all">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent z-10"></div>
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110" 
                  style={{ backgroundImage: `url('${doc.thumbnail}')` }}
                ></div>
                
                {doc.pageCount && (
                   <div className="absolute top-3 right-3 z-20 bg-black/40 backdrop-blur-md border border-white/10 px-2.5 py-1 rounded-full flex items-center gap-1">
                    <span className="material-symbols-outlined text-white text-[10px]">description</span>
                    <span className="text-[10px] font-bold text-white">{doc.pageCount} pgs</span>
                  </div>
                )}
                
                {doc.type === 'jpg' && (
                  <div className="absolute top-3 right-3 z-20 bg-black/40 backdrop-blur-md border border-white/10 px-2.5 py-1 rounded-full flex items-center gap-1">
                    <span className="material-symbols-outlined text-white text-[10px]">image</span>
                    <span className="text-[10px] font-bold text-white">JPG</span>
                  </div>
                )}
              </div>
              <div className="px-1">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-slate-900 dark:text-white text-sm truncate pr-2 leading-tight">{doc.title}</h3>
                  <button className="text-gray-400 hover:text-slate-900 dark:hover:text-white -mt-1 -mr-2 p-1 rounded-full hover:bg-black/5 dark:hover:bg-white/10">
                    <span className="material-symbols-outlined text-[18px]">more_vert</span>
                  </button>
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{doc.date} • {doc.size}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="py-8 flex flex-col items-center justify-center opacity-50 gap-2">
          <span className="material-symbols-outlined text-3xl text-gray-500">check_circle</span>
          <p className="text-xs text-gray-500 font-medium">You're all caught up</p>
        </div>
      </main>

      {/* FAB */}
      <div className="absolute bottom-24 right-5 z-40">
        <button onClick={onScan} className="group relative flex size-16 items-center justify-center rounded-full bg-gradient-to-tr from-primary to-indigo-500 text-white shadow-glow hover:scale-105 active:scale-95 transition-all duration-300">
          <span className="material-symbols-outlined text-[32px] group-hover:rotate-90 transition-transform duration-300">add</span>
        </button>
      </div>
    </div>
  );
};