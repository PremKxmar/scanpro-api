import { DocumentItem } from './types';

export const mockDocs: DocumentItem[] = [
  {
    id: '1',
    title: 'Receipt_Walmart.pdf',
    date: 'Oct 24, 2023',
    size: '2.4 MB',
    thumbnail: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBgb3N8X3pY17VhRdTOspIxeZSjFvxwOnCmc3dRC6pODxymqbChyRSfCNAk0b4rnmL605FP-C_kUvrgiZ2OGBNXKJR5QK7XAGnOQdB8bxEbrExI3y2xAUqtGQ1D-in8tmbifg52QQlH26LChBL_kVzdVgef_Lv1ZOQoNsecgkxdU6iT1NgDyPBYw58gQunWzVXOhKu1MC6mxnVVCDoeCjUjSkSfRhV2jzuOsNVDzx2fx2QaCJpm-lTRm3rqy1Auware93th8H2_RmR0',
    type: 'pdf',
    pageCount: 1
  },
  {
    id: '2',
    title: 'Contract_Signed.pdf',
    date: 'Oct 22, 2023',
    size: '8.1 MB',
    thumbnail: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBLSuT-nIR-a-tEbfeJ0Oo2vEGo69AXsH5SQ6snG6wA79uNuRMd8LVT8d32OP_p6-xU_FErblFX2l6h9lClmUnfAZGlaWBN1MSJ4hlSNvf2sEZMmIZXwvEetV3seIc9NVzqT63kz1lZ1BKhV4_xeBbQ0e5dDj7Yugctl8klza1VMMY2ykLaWfXdPCiOVszsO45IFkvZ1VsHV_NjWXYO_KHVB1BGGF0PNWgoylasFkZo5vAct4vmCsHiu1y6drwuaH5ALwFuwNl1vsjO',
    type: 'pdf',
    pageCount: 12
  },
  {
    id: '3',
    title: 'Design_Sketch.jpg',
    date: 'Oct 20, 2023',
    size: '5.2 MB',
    thumbnail: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAo2XtpRfH0JcGATTm8x6AcP1B7u4lYccTYMMZQxL9GMcALj2xjVdP47m2E1acJ8O0Mz-3ZxNjDzXywol9FLSuoYo__Wo8AJc8Leius09GMs__nP4Q2GRjKcuCFFeQNiDJHyCdXsLOb8lHuzwsOz8FyyKudvqGlk-n4OdKI7lkpMjnSkkvhZ7TQ2L-DSH1X-TeT3LYD6ODKKKKJOkmPGgf7rynSuAy9qiVVG1C-Wuun8pcDb-HoUGUN0t3I9QnNwT0qWa7s-Ftiu3_p',
    type: 'jpg'
  },
  {
    id: '4',
    title: 'Insurance_Policy.pdf',
    date: 'Sep 15, 2023',
    size: '1.1 MB',
    thumbnail: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDjJJS1gJhM-7u5l98qnDxSBSDm8-kbNjj4_hq_vOx78CV77mZ0HUXX5ptLfkbi1We2DCzTSkSLkp5uhPELbUx3lHfZuRWTuafJ5r62kwPd55mFGB1Pg2IYJaiZlG121GjUXRx-YIyMk2M6deaSUz4Jpvql7xzWO89mHaWZTjtIQcEm-kp6CGn4lxKEtBU2SscelOSi4N1UeVPoFdaig_gMcNgvZygtK0cHo-gJDhhgg4n1efEerR74J6MgT1QFLNUdC8KnMr5OrTxj',
    type: 'pdf',
    pageCount: 4
  }
];
