import React, { useState, useEffect } from 'react';
import { SplashScreen } from './screens/SplashScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { LibraryScreen } from './screens/LibraryScreen';
import { CameraScreen } from './screens/CameraScreen';
import { EditScreen } from './screens/EditScreen';
import { ResultScreen } from './screens/ResultScreen';
import { ViewerScreen } from './screens/ViewerScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { ToolsScreen } from './screens/ToolsScreen';
import { BottomNav } from './components/BottomNav';
import { mockDocs } from './store';
import { Screen, DocumentItem, ThemeContextType } from './types';

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [isDark, setIsDark] = useState(true);

  // Initialize theme
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);
  const themeContext: ThemeContextType = { isDark, toggleTheme };

  const handleNavigate = (s: Screen) => {
    setScreen(s);
  };

  const handleViewDoc = (id: string) => {
    setSelectedDocId(id);
    setScreen('viewer');
  };

  const getDoc = () => {
    return mockDocs.find(d => d.id === selectedDocId) || mockDocs[0];
  };

  // Rendering logic based on screen state
  const renderScreen = () => {
    switch (screen) {
      case 'splash':
        return <SplashScreen onFinish={() => setScreen('onboarding')} />;
      case 'onboarding':
        return <OnboardingScreen onComplete={() => setScreen('library')} />;
      case 'camera':
        return <CameraScreen onCapture={() => setScreen('edit')} onCancel={() => setScreen('library')} />;
      case 'edit':
        return <EditScreen onDone={() => setScreen('result')} onBack={() => setScreen('camera')} />;
      case 'result':
        return <ResultScreen onAddPage={() => setScreen('camera')} onRetake={() => setScreen('camera')} onFinish={() => setScreen('library')} />;
      case 'viewer':
        const doc = getDoc();
        return <ViewerScreen onBack={() => setScreen('library')} title={doc.title} size={doc.size} />;
      case 'settings':
        return <SettingsScreen onBack={() => setScreen('library')} themeContext={themeContext} />;
      case 'tools':
        return (
            <>
                <ToolsScreen />
                <BottomNav currentScreen="tools" onNavigate={handleNavigate} />
            </>
        );
      case 'library':
      default:
        return (
          <>
            <LibraryScreen onScan={() => setScreen('camera')} onViewDoc={handleViewDoc} />
            <BottomNav currentScreen="library" onNavigate={handleNavigate} />
          </>
        );
    }
  };

  return (
    <div className="w-full h-full min-h-screen relative bg-black">
        {renderScreen()}
    </div>
  );
}
